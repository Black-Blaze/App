package com.opdevs.covon_21;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    ImageView qr;
    FirebaseDatabase database;
    DatabaseReference user;
    Random rand = new Random();
    Intent signin;
    Intent mScanInt;
    Intent mInfoInt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseApp.initializeApp(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        qr = findViewById(R.id.qr);


        if(FirebaseAuth.getInstance().getCurrentUser() == null){
            signUp();
        }else{
            database = FirebaseDatabase.getInstance();
            user = database.getReference("users/"+FirebaseAuth.getInstance().getCurrentUser().getUid()+"/key");
            main();
        }

        //bottomsheet
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainactionbar, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.scan:
                scanFunc();
                return true;
            case R.id.knowledge:
                knowledgeFunc();
                return true;
            case R.id.info:
                infoFunc();
                return true;
        }
        return true;
    }

    public void scanFunc(){
        mScanInt = new Intent(this, scan.class);
        startActivity(mScanInt);
    }

    public void knowledgeFunc(){
        mInfoInt = new Intent(this, scan.class);
        startActivity(mScanInt);
    }

    public void infoFunc(){
        mInfoInt = new Intent(this, scan.class);
        startActivity(mScanInt);
    }

    public void signUp(){
        signin = new Intent(this, auth.class);
        signin.putExtra("RedirectActivity", "main");
        startActivity(signin);
    }

    public String URIFormat(String str){
        str = str.replace(" ", "%20");
        return str;
    }

    public String QRURL(String str){
        return "https://covon-22.black0blaze.repl.co/qr/"+ str;
    }

    public String randChar(int num){
        rand = new Random();
        String charString = "0123456789abcdefghijklmnopqrstuvwxyz";//!@#$%^&*()\\][;,./<>?:{}|=-_+";
        //List<Character> chars = new ArrayList<>();//convertStringToCharList("0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()\\][;,./<>?:{}|=-_+");
        StringBuilder pseudo = new StringBuilder();
        //for(char c : charString.toCharArray()){
        //    chars.add(c);
        //}

        for(int i = 0; i < num;i++){
            pseudo.append(charString.charAt(rand.nextInt(charString.length())));
        }
        Toast.makeText(MainActivity.this, pseudo.toString(), Toast.LENGTH_SHORT).show();
        return pseudo.toString();
    }

    public void genQR() {
        String tempKey = FirebaseAuth.getInstance().getCurrentUser().getUid() + randChar(10);
        String QRurl = URIFormat(QRURL(tempKey));
        user.setValue(tempKey.substring(tempKey.length()-10), tempKey.length());
        Glide.with(getApplicationContext()).load(Uri.parse(QRurl)).into(qr);
    }

    public void main(){
        genQR();
    }
}