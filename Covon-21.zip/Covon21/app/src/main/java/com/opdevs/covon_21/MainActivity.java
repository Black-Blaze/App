package com.opdevs.covon_21;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    ImageView qr;
    FirebaseDatabase database;
    DatabaseReference user;
    Random rand = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseApp.initializeApp(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        qr = findViewById(R.id.qr);


        if(FirebaseAuth.getInstance().getCurrentUser() == null){
            signUp();
        }else{
            database = FirebaseDatabase.getInstance();
            user = database.getReference(FirebaseAuth.getInstance().getCurrentUser().getUid());
            main();
        }
    }

    @SuppressWarnings("SpellCheckingInspection")
    public void signUp(){
        Intent signin = new Intent(this, auth.class);
        signin.putExtra("RedirectActivity", "main");
        startActivity(signin);
    }

    public String URIFormat(String str){
        str = str.replace(" ", "%20");
        return str;
    }

    public String QRURL(String str){
        return "https://covon-22.black0blaze.repl.co/qr/"+ str;
    }

    public String randChar(int num){
        rand = new Random();
        String charString = "0123456789abcdefghijklmnopqrstuvwxyz";//!@#$%^&*()\\][;,./<>?:{}|=-_+";
        //List<Character> chars = new ArrayList<>();//convertStringToCharList("0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()\\][;,./<>?:{}|=-_+");
        StringBuilder pseudo = new StringBuilder();
        //for(char c : charString.toCharArray()){
        //    chars.add(c);
        //}

        for(int i = 0; i < num;i++){
            pseudo.append(charString.charAt(rand.nextInt(charString.length())));
        }
        Toast.makeText(MainActivity.this, pseudo.toString(), Toast.LENGTH_SHORT).show();
        return pseudo.toString();
    }

    public void genQR() {
        String tempKey = FirebaseAuth.getInstance().getCurrentUser().getUid() + randChar(10);
        String QRurl = URIFormat(QRURL(tempKey));
        Glide.with(getApplicationContext()).load(Uri.parse(QRurl)).into(qr);
    }

    public void main(){
        genQR();
    }
}