package com.opdevs.covon_21;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.Result;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class scan extends AppCompatActivity {

    CodeScanner scanner;
    Intent inet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);
        CodeScannerView cam = findViewById(R.id.qrScanner);
        scanner = new CodeScanner(this, cam);
        scanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull Result result) {
                scan.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        out(result);
                    }
                });
            }
        });
        scanner.startPreview();
    }

    private void out(Result result){
        String tempKey = result.getText();
        String key = tempKey.substring(tempKey.length()-10);
        String usr = tempKey.substring(0 , tempKey.length()-11);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference userKey = database.getReference("users/"+ usr+"/key");
        //DatabaseReference userData = database.getReference("users/"+ usr+"/key");
        try {
            Toast.makeText(scan.this, read(userKey), Toast.LENGTH_SHORT).show();
        }catch(Exception e){
            Toast.makeText(scan.this, "Invalid QR", Toast.LENGTH_SHORT).show();// e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
    String data = "";

    private String read(DatabaseReference ref){
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                scan.this.data = snapshot.getValue().toString();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return data;
    }

    private void show(Boolean vcc){
        View a = findViewById(R.id.a);
        TextView b = findViewById(R.id.b);
        if(vcc){
            //a.setBackgroundColor(getResources().(R.color.green);
            b.setText("Vaccinated");
        }else{
            //a.setBackgroundColor(dsffnsdgetResources().(R.color.red));
            b.setText("Not Vaccinated");
        }
    }
}